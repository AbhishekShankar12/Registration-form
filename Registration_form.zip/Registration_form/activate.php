<?php

include ('db.php');



   $token = sha1(uniqid($email, true));

   $query ="INSERT INTO registerdata (email, token, timess) VALUES (?, ?, ?)";

   $url="http://localhost/Registration_form/activate.php?token=$token ";



   if (isset($_GET["token"]) && preg_match('/^[0-9A-F]{40}$/i', $_GET["token"])) {
    $token = $_GET["token"];
   }
   else {
    throw new Exception("Valid token not provided.");
   }

   // verify token
   $query = "SELECT email, timess FROM registerdata WHERE token = ?";
   $query->execute(array($token));
   $row = $query->fetch(PDO::FETCH_ASSOC);
   $query->closeCursor();

   if ($row) {
    extract($row);
   }
   else {
    throw new Exception("Valid token not provided.");
   }

   // do one-time action here, like activating a user account
   // ...

   // delete token so it can't be used again
   $query =
    "DELETE FROM registerdata WHERE email = ? AND token = ? AND timess = ?",;
   
































   // session_start();

   // include'db.php';

   // if (isset($_GET['token'])) {
   	
   // 	$token $_GET['token'];


   // 	$timess = $_POST['timess']; 
	// 	$update_time = $_POST['update_time']; 
	 
	// 	$from_time = strtotime($timess); 
	// 	$to_time = strtotime($update_time); 
	// 	$diff_minutes = round(abs($from_time - $to_time) / 3600). " minutes";

   // 	$updatequery =" select *, diff_minutes(second, timess, update_time) from registerdata where token='$token' ";

   // 	$query = mysqli_query($conn, $updatequery);


   // 	if($query){
   // 		if(isset($_SESSION['msg'])){
   // 			$_SESSION['msg'] = "Account update successful";
   // 			header('location:login.php');
   // 		}else{
   // 			$_SESSION['msg'] = "You are logged out.";
   // 			header('location:login.php'); 
   // 		}else{
   // 			$_SESSION['msg'] = "Account not updated"
   // 			header('location:register.php');
   // 		}
   // 	}
   // }

?>