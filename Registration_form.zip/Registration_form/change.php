<?php
session_start();
include("db.php");
if(isset($_POST['submit']))
{


 $newpassword=addslashes($_POST['passwordd']);
 $password = addslashes( $_POST['password']);
 $confirm=addslashes($_POST['confirm']);
 $id = $_SESSION['id'];




    $new_password = md5($newpassword);
    $con_pass = md5($confirm);
    $password=md5($password);

    $query="select `userpassword` from `registerdata` where `id`=$id";
    $result = mysqli_query($conn,$query);
    $data = mysqli_fetch_assoc($result);


    // echo '<pre>';
    // print_r($data);
    // echo '</pre>';

    // exit();
        
    // while($row = mysqli_fetch_assoc($result)){
    //     $check_pass=$row['password'];
    // }
    if(strcmp($password, $data['userpassword'])){
            if ($new_password === $con_pass) 
        {
           $conn=mysqli_query($conn,"update registerdata SET userpassword='".$new_password."' where `id`=$id");
           $_SESSION['msg1']="Password Changed Successfully !!";

        }
        else{
             $_SESSION['msg1']="Confirm Password not match !!";
        }

    }else{
         $_SESSION['msg1']="Old Password not match !!";
    }

    // if ($password!= $data['userpassword']) {


           
        


    //     }
    //     elseif ($new_password === $con_pass) 
    //     {
    //        $conn=mysqli_query($conn,"update registerdata SET userpassword='".$new_password."' where `id`=$id");
    //        $_SESSION['msg1']="Password Changed Successfully !!";

    //     }
    //     else
    //     {
           
    //     }

}
   




?>

<?php
include('header.php');

?>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">

        <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>




    </ul>
</div>
</nav>
<div class="container">

    <br>
    <br>
    <br>
    

    <div class="login-form">

      <div class="main-div">

        <div class="panel">

          <h2>Change Your Password</h2>
          <p>   </p>

      </div>

      <div>
          <p class="bg-succeess text-white px-4"> 
          </p>
      </div>

      <small style="color:red;"><?php echo $_SESSION['msg1'];?><?php echo $_SESSION['msg1']="";?></small>

      <form    action="" method="POST" id="chgpas">

        <div class="form-row">

            <div >





                <div >
                    <label  for="old">Old Password : </label>
                    <input type="password" class="form-control " name="password" id="password" placeholder="Old Password" >
                    <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
               <!--  <input class="checkbox" type="checkbox" onclick="myfunc()">Show Password
                <script>

                        function myfunc(){
                                var x = document.getElementById("validationCustom04");
                                if (x.type === "password"){
                                        x.type = "text";
                                } else{
                                        x.type = "password"
                                }
                        }
                    </script> -->

                </div>

                <label  for="password"> New Password : </label>
                <input type="password" class="form-control" name="passwordd" id="passwordd" placeholder=" New Password" >
                <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                               <!--  <input class="checkbox" type="checkbox" onclick="myfunction()">Show Password
                                <script>

                                        function myfunction(){
                                                var x = document.getElementById("validationCustom03");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                    </script> -->
                                </div>

                                <div >
                                    <label  for="confirm">Confirm Password : </label>
                                    <input type="password" class="form-control " name="confirm" id="confirm" placeholder="Confirm Password" >
                                    <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                               <!--  <input class="checkbox" type="checkbox" onclick="myfunc()">Show Password
                                <script>

                                        function myfunc(){
                                                var x = document.getElementById("validationCustom04");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                    </script> -->

                                </div>
                            </div>        





                            <button class="btn btn-primary" type="submit" name="submit" value="submit"> Submit</button>


                        </form>

                    </div>

                    <p class="botto-text"></p>

                </div>

            </div>



        </body>


<!--         <script type="text/javascript">
            function valid()
            {
                if(document.chgpas.old.value=="")
                {
                    alert("Old Password Filed is Empty !!");
                    document.chgpas.old.focus();
                    return false;
                }
                else if(document.chgpas.password.value=="")
                {
                    alert("New Password Filed is Empty !!");
                    document.chgpas.password.focus();
                    return false;
                }
                else if(document.chgpas.confirm.value=="")
                {
                    alert("Confirm Password Filed is Empty !!");
                    document.chgpas.confirm.focus();
                    return false;
                }
                else if(document.chgpas.password.value!= document.chgpas.confirm.value)
                {
                    alert("Password and Confirm Password Field do not match  !!");
                    document.chgpas.confirm.focus();
                    return false;
                }
                return true;
            }
        </script> -->

        </html>

