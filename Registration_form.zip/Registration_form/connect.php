<?php

 include("db.php");

	if(isset($_POST['submits'])){
		$name = addslashes( $_POST['name']);
		$username = addslashes( $_POST['username']);
		$email = addslashes( $_POST['email']);
		$password = addslashes( $_POST['password']);
		$confirm = addslashes( $_POST['confirm']);
		$gender = addslashes( $_POST['gender']);
		$phone = addslashes( $_POST['phone']);
		$age = addslashes( $_POST['age']);
		$hobbies = addslashes( $_POST['hobbies']);
		$dob = addslashes( $_POST['dob']);
		$file = addslashes( $_POST['file']);
		$token = addslashes( $_POST['token']);
		$timess = addslashes( $_POST['timess']);
		$update_time = addslashes( $_POST['update_time']);
		



		$pass = md5($password);
		//$cpass = md5($confirm);
		$token = bin2hex(random_bytes(15));

		$emailquery = "select * from registerdata where email='$email' ";
		$query = mysqli_query($conn, $emailquery);
		if(mysqli_num_rows($query) > 0)
		{
			$_SESSION['status'] = "Email already exists.";
			header('location: register.php');
		}

		else{
			if ($password === $confirm) {


		    	$insertquery = "INSERT  INTO registerdata (name, username, email, userpassword, gender, age, phone, hobbies, dob, file, token)
		    	VALUES('$name', '$username', '$email', '$pass', '$gender', $age , $phone, '$hobbies', '$dob', '$file', '$token' )";


		    	$iquery = mysqli_query($conn, $insertquery);
		    	
		    	header("Location: login.php");
				exit();


				if ($iquery) {
					
				$subject = "Email Activation";
				$body = "Hi, $username. click here to activate your account
				http://localhost/Registration_form/activate.php?token=$token ";
				$sender_email = "From: admin_1@gmail.com";

				if(mail($email, $subject, $body, $sender_email)){
					$_SESSION['msg'] = "Check you mail to activate your account $email";
					header('location: login.php');
				}else{
					echo "Email sending failed...";
				}

				}else
				{
					?>
						<script>
							alert("not inserted");
						</script>
					<?php
				}
    	
				
			}else{
				echo header ('location: register.php');
			}

			
		}

	

	} 




?>


