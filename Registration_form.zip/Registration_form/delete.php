<?php
include('db.php');

if (isset($_GET['deleteid'])) {
	$id = $_GET['deleteid'];

	$sql = "DELETE FROM `news` WHERE id=".$id;
	$result = mysqli_query($conn, $sql);

	if ($result) {
		$_SESSION['msg'] = "Edit successful";
		header('location:news.php?insertquery=true&page');
	}else{
		$_SESSION['msg'] = "Edit un--successful";
	}
}

?>