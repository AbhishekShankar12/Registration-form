<?php
include('db.php');

if (isset($_POST['save'])) {


    $titlee = addslashes( $_POST['title']);
    $descriptionn = addslashes( $_POST['description']);
    $dateee =  $_POST['datee'];
    $statuss = $_POST['status'];
    $id = $_GET['editid'];


	$sql = "UPDATE `news` SET title ='$titlee', description ='$descriptionn', datee ='$dateee',status ='$statuss' WHERE id=".$id;

	
	 $result = mysqli_query($conn, $sql);

	

	if ($result == false) {
		echo '<script>alert("Edit successful")</script>';

		header('location:news.php');
		exit();
	}else{
		echo "un--successs";
		header('location:news.php?insertquery=true&page');
		exit();
	}

}


?>




<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="style/style.css">

  


  <!-- Script file -->        
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>
  <script src="ckeditor/ckeditor.js"></script>

  <title> </title>
<style >
  input[type=submit]{
    width: 15%;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;

  }

</style>  
     

</head>

<body>
  <img class="bg" src="bggg.jpg">
  <!-- Nav Menu -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Php Login System</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>


    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="home.php">Home</a>
      </li>
      <li class="nav-item">
       <a class="nav-link" href="profile.php">Profile</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="logout.php">Logout</a>
    </li>
  </ul>



</nav>


<?php


$id = $_GET['editid'];

$sql = "SELECT * FROM `news` WHERE `id`=".$id;
$result = mysqli_query($conn,$sql);
$res = mysqli_num_rows($result);
if($res>0){
  $value = mysqli_fetch_assoc($result); 
}
  ?>

  <form action="#" method="POST">
    <div class="form-group row">
      <label for="title">Title: </label>
      <div class="col-md-4 mb-2">
      <input type="text"  name="title" value="<?php echo $value['title']; ?>" placeholder="Enter Title..">
    </div>
    </div>
      

      <div class="form-group row">
        <label for="Description">Description</label>
        <div class="col-md-4 mb-2">
        <textarea type="text" cols="70" rows="6" id="lname"  name="description" placeholder="Your Description..">
          <?php echo $value['description']; ?>
        </textarea>
        <script>
                        CKEDITOR.replace( 'description' );
        </script>
        </div>
      </div>

      <div class="form-group row">
        <label for="Date">Date</label>
        <div class="col-md-2 mb-2">
        <input type="date" value="<?php echo $value['datee']; ?>" name="datee" >
        </div>
      </div>

      <div class="form-group row">
        <label for="status">Status</label>
        <div class="col-md-4 mb-2">
        <select id="status" name="status">
          <option value="Publish" <?php if ($value['status'] == "publish") { echo "selected"; } ?>>Publish</option>
          <option value="Draft" <?php if ($value['status'] == "draft") { echo "selected"; } ?> >draft</option>
        </select>
        </div>
      </div>
      <div class="form-group row">
        <div class="col-md-4 mb-2">
        <input type="submit" value="save" name="save">
        </div>
      </div>
    </div>

    </form>

  </body>
</html>