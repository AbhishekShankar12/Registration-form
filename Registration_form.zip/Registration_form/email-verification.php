<?php 
include('db.php');

if(isset($_POST['email']) && !empty($_POST['email']) ){
        $email = $_POST['email'];

        $emailquery = "select * from registerdata where email='$email' ";
        $email_query_run = mysqli_query($conn, $emailquery);

        if(mysqli_num_rows($email_query_run) > 0 ) 
        {
                echo "Email already exists";
        }
        else{
                echo "its available";
        }  
}

   die();   






?>