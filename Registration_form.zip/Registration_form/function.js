jQuery('#reg_page').validate({

rules:{
	name:"required",
	username:"required",
	email:"required",
	password:{
		required:true,
		minlength:5
	},
	confirm:{
		required:true,
		minlength:5
	},
	gender:"required",
	phone:{
		required:true,
		minlength:10
	},
	desc:{
		required:true,
	},

},
messages:{
	name:"Please enter your name",
	username:"Please enter your username",
	email:"Please enter your email",
	password:"Please enter your password",
	confirm:{
		required:"Please confirm your password",
		minlength:"Minimum length 5"
	},
	gender:"Please confirm your gender",
	phone:{
		required:"Please enter your phone no.",
		minlength:"Minimum length 10"
	},
	desc:{
		required:"Please add any comment",
	},

}

})







	










