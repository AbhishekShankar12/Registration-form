<?php
include('header.php');
?>

<div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">

                <?php if (isset($_SESSION["logged_in"])): ?>
                        <li class="nav-item active">
                                <a class="nav-link" href="#home.php">Home <span class="sr-only"></span></a>
                        </li>
                        <?php 
                endif; 
                ?>

                <li class="nav-item">
                        <a class="nav-link" href="index.php">Register</a>
                </li>

                <?php if (! isset($_SESSION["logged_in"])): ?>
                        <li class="nav-item">
                                <a class="nav-link" href="login.php">Login</a>
                        </li>
                <?php endif; ?>

        </ul>
</div>
</nav>


<div class="container form-container">
        <h1>REGISTRATION FORM </h1>
        <p>Enter your details and submit the form to let us know your visit</p>
        <br>
        <br>
        <br>
        <form  onsubmit="return myfun()"  action="connect.php" method="POST" id="reg_page">
                <h7>* Required Filed </h7>
                <br>
                <br>
                <div class="form-row row">
                        <div class="col-md-4 mb-2">
                                <label  class="required"  for="validationCustom01">NAME : </label>
                                <input type="text" class="form-control" name="name" id="validationCustom01" placeholder="Enter your name" 
                                required>
                        </div>




                        <div class="col-md-4 mb-2">
                                <label  for="validationCustomUsername">Username</label>
                                <div class="input-group">
                                        <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend">@</span>
                                        </div>
                                        <input type="text" class="form-control" name="username" id="validationCustomUsername" placeholder="Username" aria-describedby="inputGroupPrepend" required>
                                </div>
                        </div>


                </div>

                <div class="form-row row">                

                        <div class="col-md-8 mb-3">
                                <label class="required"  for="validationCustom02">Email : </label>
                                <input type="text" class="form-control checking_email"  name="email"  id="validationCustom02" placeholder=" Email" required>
                                <small class="error_email" style="color: red;"> </small>
                        </div>


                </div>                

                <div class="form-row row">

                        <div class="col-md-4 mb-3">

                                <label  for="validationCustom03">Password : </label>
                                <input type="password" class="form-control" name="password" id="validationCustom03" placeholder=" Password" required>
                                <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                                <input class="checkbox" type="checkbox" onclick="myfunction()">Show Password
                                <script>

                                        function myfunction(){
                                                var x = document.getElementById("validationCustom03");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                </script>
                        </div>

                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom04">Confirm Password : </label>
                                <input type="password" class="form-control " name="confirm" id="validationCustom04" placeholder="Confirm Password" required>
                                <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                                <input class="checkbox" type="checkbox" onclick="myfunc()">Show Password
                                <script>

                                        function myfunc(){
                                                var x = document.getElementById("validationCustom04");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                </script>

                        </div>
                </div>        
                
                <div class="form-row row">                

                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom05">GENDER : </label>
                                <input type="radio"  name="gender" id="validationCustom05" value="m">Male
                                <input type="radio"  name="gender" id="validationCustom05" value="f"> FeMale
                                <input type="radio"  name="gender" id="validationCustom05" value="o"> Others
                                
                        </div>
                </div>

                <div class="form-row row">  

                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom06">AGE : </label>
                                <input type="number" class="form-control" name="age" id="validationCustom06" placeholder="Age" required>
                        </div>



                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom07">PHONE : </label>
                                <input type="number" class="form-control" name="phone" id="validationCustom07" placeholder="Phone" required>
                        </div>


                </div>
                

                <div class="form-row">                


                        <div class="col-md-4 mb-3">
                                <label for="validationCustom08">HOBBIES : </label>
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="c" > Cricket
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="f" >Football
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="v" >Vollyball
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="b" >Badminton
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="l" >Listning music
                                <input type="checkbox" name="hobbies" id="validationCustom08" value="r" >Reading books
                        </div>

                </div>
                
                <div class="form-row row">



                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom09">DOB : </label>
                                <input type="date" class="form-control" name="dob" id="validationCustom09"  required>
                        </div>


                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom011">SELECT FILE : </label>
                                <input type="File" name="file" class="form-control"  id="validationCustom011"  required>
                        </div>


                </div>
                

                <div class="form-row">                


                        <div class="col-md-4 mb-3">
                                <label class="required" for="validationCustom012">COMMENT : </label>
                                <textarea name="desc"  rows="5" cols="10" class="form-control"  id="validationCustom012" placeholder="Commets " required></textarea>
                        </div>

                        <button class="btn" id="btn_disable" type="submit" name="submits"> Submit </button>
                        <button class="btn"> Reset </button>

                </div>

        </form>

</div>


<script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>

<script>

        $(document).ready(function ()  {

                $('.checking_email').change(function (e) {

                        var email = $('.checking_email').val();

                        if(email == '') {
                                $('.error_email').text('');
                        }else{
                                $.ajax({
                                        type: "POST",
                                        url: "email-verification.php",
                                        data: {
                                                "email": email,
                                        },
                                        success: function(response){
                                                //alert(response);
                                                $('.error_email').text(response);
                                        }

                                });
                        }


                });
        });

</script>


<script>
        $(document).ready(function () {
                $("#validationCustom04").on('keyup', function(){
                        var password = $("#validationCustom03").val();
                        var confirm = $("#validationCustom04").val();
                        if (confirm != password){
                                $("#CheckPasswordMatch").html("Password does not match !").css("color","red");
                                $("#btn_disable").attr("disabled", "disabled");
                        }else{
                                $("#CheckPasswordMatch").html("Password match !").css("color","maroon");
                                $("#btn_disable").removeAttr("disabled", "disabled");
                        }
                });
        });
</script>



<script src="function.js"></script>

</body>