<?php
include('db.php'); 
session_start();
if(isset($_POST["login"]))  
{ 


  if(empty($_POST["username"]) && empty($_POST["userpassword"]))  
  {  
   echo '<script>alert("Both Fields are required")</script>';  
 }  
 else  
 {  
   $username = mysqli_real_escape_string($conn, $_POST["username"]);  
   $password = mysqli_real_escape_string($conn, $_POST["password"]);  

   $password = md5($password);  

   $query = "SELECT * FROM registerdata WHERE username = '$username' AND userpassword = '$password'";  
   $result = mysqli_query($conn, $query);  
   if(mysqli_num_rows($result) > 0) 
   {   

    $data=mysqli_fetch_assoc($result);


    $_SESSION['id'] = $data['id'];
    $_SESSION['msg'] = 'User logged in !!';
    $_SESSION['username'] = $data['username']; 
    $_SESSION['logged_in'] = true; 

    header("location: home.php");
    exit();  
  }  
  else  
  {  
    echo '<script>alert("Wrong User Details")</script>';  
  }  
}  
}  



?>





<?php
include('header.php');

?>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Register</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="login.php">Login</a>
    </li>




  </ul>
</div>
</nav>




<div class="container">

  <br>
  <br>
  <br>


  <div class="login-form">

    <div class="main-div">

      <div class="panel">

        <h2>Admin login</h2>
        <p>Enter username and password </p>

      </div>

      <div>
        <p class="bg-succeess text-white px-4"> 
          <?php 
          
          if(isset($_SESSION['msg'])){
           echo $_SESSION['msg'];
         }else{
           echo $_SESSION['msg'] = "You are logged out. Login again. ";
         }
         
       ?> </p>
     </div>

     <form id="login" method="POST" action="login.php">
      <div class="form-group">
        <input type="text" value="<?php if (isset($_COOKIE["user"])) {echo $_COOKIE["user"];} ?>" name="username" class="form-control" id="uname" placeholder="Enter your username">

      </div>


      <div class="form-group">
        <input type="password" value="<?php if (isset($_COOKIE["pass"])) {echo $_COOKIE["pass"];} ?>" name="password" class="form-control" id="inputpassword" placeholder="Password">

      </div>

      <div class="form-group" style="text-align: left;">
        <label><input type="checkbox" value="<?php if (isset($_COOKIE["user"])  &&  isset($_COOKIE["pass"])) {echo "checked";} ?>" name="remember "> Remember me </label>

      </div>


      <div class="forgot">
        <a href="recover_email.php"> Forgot Paassword? </a>

      </div>

      <input type="submit" class="btn btn-primary" value="login" name="login">


    </form>

  </div>

  <p class="botto-text"> By Nethues</p>

</div>

</div>

</body>

</html>

