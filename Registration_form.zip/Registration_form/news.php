<?php
session_start();
include('db.php');

if (isset($_POST['save'])) {


       $title = addslashes( $_POST['title']);
       $description = addslashes( $_POST['description']);
       $datee =  $_POST['datee'];
       $status = $_POST['status'];

       $insertquery="INSERT INTO news (title, description, datee, status) VALUES ('$title','$description','$datee','$status')";
       // echo $insertquery;

       $result=mysqli_query($conn, $insertquery);

         if($result == false){
                echo "please try again";
                header('location:news.php');
                exit();
         }else{
                header('location:news.php?insertquery=true&page=1');

                exit();
         }
     }


     // $num_per_page=05;

     // if(isset($_GET["page"]))
     // {
     //  $page=$_GET["page"];
     // }else{
     //  $page=1;
     // }

     // $start_from=($page-1)*05;

     // $sql="select * from news limit $start_from, $num_per_page";
     // $result=mysqli_query($conn,$sql);
?>


<!DOCTYPE html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="style/style.css">

        <!--  -->

   <!--      <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="https://cdn.datatables.net/1.13.3/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.3/js/dataTables.bootstrap4.min.js"></script>
 -->
 
        <!-- Script file -->        
        
        <script src="ckeditor/ckeditor.js"></script>
        <title> </title>


          
</head>

<body>
        <img class="bg" src="bggg.jpg">
          <!-- Nav Menu -->
          <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Php Login System</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

        
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="home.php">HOME</a>
              </li>
                <li class="nav-item">
                 <a class="nav-link" href="profile.php">PROFILE</a>
               </li>
               <li class="nav-item">
                <a class="nav-link" href="logout.php">LOGOUT</a>
              </li>
            </ul>
          


        </nav>
<div>
<?php
     if (isset($_GET['insertquery']) && !empty($_GET['insertquery'])) {
             ?>
             <button ><a href="news.php">ADD NEWS</button>
             <table class="table" id="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Title</th>
                  <th scope="col">Description</th>
                  <th scope="col">Date</th>
                  <th scope="col">Status</th>
                  <th scope="col">Operation</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $per_page=5;
                $start = 0;
                $current_page=1;
                if (isset($_REQUEST['page'])) {
                      $start=$_REQUEST['page'];
                      if ($start<=0) {
                      $start=0;
                      $current_page=1;
                      }else
                      {
                        $current_page=$start;
                        $start--;
                        $start=$start*$per_page;
                      }
                }
                // echo '<pre>';
                // print_r($start);
                // echo '<pre>';
             
             
                
                
                $res = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM news"));


                $pagi=ceil($res/$per_page);

                $selectt="select * from news limit $start,$per_page";
          
                $resultt = mysqli_query($conn,$selectt);
                //echo $resultt;

                if($res>0 && ($_REQUEST['page'] <=$pagi)){
                  $i=1;
                  while($data=mysqli_fetch_assoc($resultt)){
                   
                    ?>
                    <tr>
                      <th scope="row"><?php echo $i; ?></th>
                      <td><?php echo $data['title']; ?></td>
                      <td><?php echo strip_tags( $data['description']) ; ?></td>
                      <td><?php echo $data['datee']; ?></td>
                      <td><?php echo $data['status']; ?></td>
                      <td>
                        <button type="button" class="primary" ><a href="edit.php?editid=<?php echo $data['id'];?>">EDIT</button>
                        <button   type="button" class="danger"><a href="delete.php?deleteid=<?php echo $data['id'];?>" onclick="return confirm('Are you sure you want to delete this item?');">DELETE</button>
                      </td>
                    </tr>
                    <?php
                    $i++;
                  } 
                } ?>
                </tbody>
</table>

<nav aria-label="...">
  <ul class="pagination pagination-sm">
    <?php

// $sql="select * from news";
// $result=mysqli_query($conn,$sql);
// $total_records=mysqli_num_rows($result);
// $total_pages=ceil($total_records/$num_per_page);

// for($i=1;$i<=$total_pages;$i++)
// {
//   echo "<a href='news.php?page=".$i."'>".$i."</a>";
// }
for($s=1;$s<=$pagi;$s++){




 ?>


  <li class="page-item"><a class="page-link" href="news.php?insertquery=true&page=<?php echo $s;?>"><?php echo $s;?></a></li>
  <?php 
}
?>
  </ul>
</nav>
              <?php }else{


?>

  <form action="#" method="POST">

    <div class="form-group row">
     <label for="title" >Title</label>
      <div class="col-md-4 mb-2">
        <input type="text" class="form-control" name="title" placeholder="Enter Title..">
      </div>
    </div>
 
    <div class="form-group row">
      <label for="Description" class="col-sm- col-form-label">Description</label>
      <div class="col-md-4 mb-2">
        <textarea type="text" name="description" class="form-control" cols="70" rows="6" placeholder="Your Description..">
        </textarea>
                <script>
                        CKEDITOR.replace( 'description' );
          </script>
      </div>
    </div>

      <div class="form-group row">
        <label for="Date" class="col-sm- col-form-label">Date</label>
        <div class="col-md-2 mb-1">
          <input type="date" class="form-control" name="datee">
        </div>
      </div>

        <div class="form-group row">
          <label for="status" class="col-sm-1 col-form-label">Status</label>
          <div class="col-md-4 mb-2">
          <select id="status" name="status">
            <option value="Publish">Publish</option>
            <option value="draft">draft</option>
          </select>
        </div>
      </div>

        <div class="form-group row">
        <div class="col-md-4 mb-2">
          <input type="submit" value="Save" name="save">
        </div>
        </div>

      </div>

  </form>

<!--   <script>
    $(document).ready(function(){
      $('table').DataTable({

      });
    });
  </script> -->

<?php
}
?>


