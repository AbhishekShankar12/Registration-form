<?php 
include('db.php');
session_start();
  
  $id = $_SESSION['id'];

  if (isset($_POST['update'])) {
 
  $name = addslashes( $_POST['name']);
  $username = addslashes( $_POST['username']);
  $email = addslashes( $_POST['email']);
  $phone = addslashes( $_POST['phone']);
  $file = addslashes($_POST['file']);

  $insertquery = "UPDATE registerdata SET name='".$name."',username='".$username."',email='".$email."',file='".$file."' ,phone=phone where id=".$id; 
  
 
  $iquery = mysqli_query($conn, $insertquery);
  $_SESSION['msg'] = "Account update successful";
  }
?>




<?php
include('header.php');

?> 

   <style>
      .editbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
      }

      button {
        background-color: #04AA6D;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
      }

      button:hover {
        opacity: 0.8;
      }
    </style>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
           <li class="nav-item"><a class="nav-link" href="change.php">Change Password</a></li>
          <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </nav>
    </nav>
    <div class="container"><br><br><br>
      <div class="login-form">
        <div class="main-div">
          <div class="panel">
            <h2>Profile</h2><br><br>
          
          </div>
          <?php
                $id = $_SESSION['id'];

                $sql = "SELECT `name`, `username`, `email`, `phone`,`file` FROM `registerdata` WHERE `id`=".$id;
                $result = mysqli_query($conn,$sql);
                $res = mysqli_num_rows($result);
                if($res>0){
                  $data = mysqli_fetch_assoc($result); 
          ?>

          <form method="POST" id="form" action="">

            <div class="upload">
          
              <img src="pic/<?php echo $data['file'];?>"   width = 125 height = 125  >
              <input type="File" name="file" style="width:80%" value="">
              <div>
                <small class="success" style="color:red;">  <?php echo $_SESSION['msg']; ?></small>
              </div>


            </div>
          



            <div class="form-row ">
              <div><label class="" for="validationCustom01">NAME : </label><input type="text" class="form-control" value="<?php echo $data['name']; ?>" name="name" id="validationCustom01"></div>
              <div><label for="validationCustomUsername">USERNAME</label>
                <div class="input-group">
                  <div class="input-group-prepend"><span class="input-group-text" id="inputGroupPrepend">@</span></div><input type="text" class="form-control" value="<?php echo $data['username']; ?>" name="username" id="validationCustomUsername">
                </div>
              </div>
            </div>
            <div class="form-row ">
              <div><label class="" for="validationCustom02">EMAIL : </label><input type="text" class="form-control checking_email" name="email" id="validationCustom02" value="<?php echo $data['email']; ?>"><small class="error_email" style="color: red;"></small></div>
            </div>
            <div class="form-row ">
              <div><label class="" for="validationCustom07">PHONE : </label><input type="number" class="form-control" name="phone" id="validationCustom07" value="<?php echo $data['phone']; ?>"></div>
            </div>
            <div class="container"><button type="submit" name='update' value="" class="editbtn">Update_Profile</button></div>
          </form>
        <?php } ?>
        </div>
      </div>
    </div>
    <script >
      document.location.reload='http://localhost/Registration_form/profile.php';
    </script>

  </body>
</html>