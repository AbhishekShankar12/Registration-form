<?php
include('header.php');

?>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
  <ul class="navbar-nav">

    <li class="nav-item">
      <a class="nav-link" href="login.php">Login</a>
    </li>




  </ul>
</div>
</nav>
<div class="container">

  <br>
  <br>
  <br>


  <div class="login-form">

    <div class="main-div">

      <div class="panel">

        <h2>Verify Your Account</h2>
        <p> Enter email  </p>

      </div>

      <div>
        <p class="bg-succeess text-white px-4"> 
        </p>
      </div>

      <form id="login" method="POST" action="">
        <div class="form-group">
          <input type="text" value="" name="email" class="form-control checking_email" id="emaill" placeholder="Enter your email">
          <?php

          include("db.php");

          if (isset($_REQUEST['email'])) {
            $email = addslashes( $_POST['email']);
                 // $token = $_SESSION['token'] = md5(uniqid(mt_rand(),true));

            $emailquery = "select * from registerdata where email='$email' ";
            $query = mysqli_query($conn, $emailquery);

            $row = mysqli_fetch_array($query,MYSQLI_ASSOC);

            if(mysqli_num_rows($query) > 0){
                  // echo "Token Send to your Email";
              echo '<a href="http://localhost/Registration_form/reset.php?token='.$row["token"].'&uid='.$row["id"].'">Reset Password</a>';

            }else{
              echo "No Email Found";
            }
          }

          ?>
          <small class="error_email" style="color: red;"> </small>


        </div>

        


        <button class="btn btn-primary" type="submit" name="login"> Verify</button>
        

      </form>

    </div>

    <p class="botto-text"></p>

  </div>

</div>



</body>

</html>