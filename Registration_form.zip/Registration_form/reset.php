<?php

include ('db.php');


if(isset($_POST['submit'])){


    $confirm = addslashes( $_POST['confirm']);
    $new_pass = addslashes( $_POST['password']);

    $new_password = md5($new_pass);
    $con_pass = md5($confirm);

    $id = $_GET['uid'];

    if($new_password === $con_pass)
    {
        $insertquery = "update registerdata SET userpassword='".$new_password."' where id=".$id;


        $iquery = mysqli_query($conn, $insertquery);

        header('location:login.php');
        exit();
    }else{
       echo "Password Not Matched"; 
   }
}


?>




<?php
include('header.php');

?>
<div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">

        <li class="nav-item">
            <a class="nav-link" href="login.php">Login</a>
        </li>




    </ul>
</div>
</nav>
<div class="container">

    <br>
    <br>
    <br>
    

    <div class="login-form">

      <div class="main-div">

        <div class="panel">

          <h2>Rest Your Password</h2>
          <p>   </p>

      </div>

      <div>
          <p class="bg-succeess text-white px-4"> 
          </p>
      </div>

      <form    action="" method="POST" id="reg_page">

        <div class="form-row">

            <div >

                <label  for="validationCustom03"> New Password : </label>
                <input type="password" class="form-control" name="password" id="validationCustom03" placeholder=" Password" required>
                <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                               <!--  <input class="checkbox" type="checkbox" onclick="myfunction()">Show Password
                                <script>

                                        function myfunction(){
                                                var x = document.getElementById("validationCustom03");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                    </script> -->
                                </div>

                                <div >
                                    <label class="required" for="validationCustom04">Confirm Password : </label>
                                    <input type="password" class="form-control " name="confirm" id="validationCustom04" placeholder="Confirm Password" required>
                                    <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                               <!--  <input class="checkbox" type="checkbox" onclick="myfunc()">Show Password
                                <script>

                                        function myfunc(){
                                                var x = document.getElementById("validationCustom04");
                                                if (x.type === "password"){
                                                        x.type = "text";
                                                } else{
                                                        x.type = "password"
                                                }
                                        }
                                    </script> -->

                                </div>
                            </div>        





                            <button class="btn btn-primary" type="submit" name="submit" value="submit"> Submit</button>


                        </form>

                    </div>

                    <p class="botto-text"></p>

                </div>

            </div>



        </body>

        </html>

