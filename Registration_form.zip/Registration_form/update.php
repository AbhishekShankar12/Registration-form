<!-- <?php
	include('db.php');

	if (isset($_POST['update'])) {
		$name = addslashes( $_POST['name']);
		$username = addslashes( $_POST['username']);
		$email = addslashes( $_POST['email']);
		$phone = addslashes( $_POST['phone']);

		$id = $_GET['uid'];

		if (isset($_POST['update']) && !empty($_POST['update'])) {

			$insertquery = "UPDATE registerdata SET name='".$name."',username='".$username."',email='".$email."', phone=phone where id='.$id'";
			echo $insertquery;
			echo ("hello");

            
            $iquery = mysqli_query($conn, $insertquery);

            header('location:home.php');
            exit();
		}else{
			header('location:update.php');
		}


	}

?>



<!doctype html>
<html lang="en">
  <head>
   <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="style.css">

    <title>PHP login system!</title>
    <style >
      .editbtn {
          width: auto;
          padding: 10px 18px;
          background-color: #f44336;
        }

         button {
          background-color: #04AA6D;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          cursor: pointer;
          width: 100%;
        }

        button:hover {
          opacity: 0.8;
        }
    </style>
  </head>
  <body>

         <img class="bg" src="bggg.jpg">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">Php Login System</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                </button>


                  <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                                <!-- <li class="nav-item active">
                                        <a class="nav-link" href="#home.php">Home <span class="sr-only"></span></a>
                                </li> -->

                                <li class="nav-item">
                                        
                                 <a class="nav-link" href=" home.php">Home</a>
                                </li>
                               
                                <li class="nav-item">
                                        <a class="nav-link" href="logout.php">Logout</a>
                                </li>
                        </ul>
                </div>
        </nav>        




  <div class="container">

    <br>
    <br>
    <br>
    

    <div class="login-form">

    <div class="main-div">

    <div class="panel">

      <h2>Edit_Profile</h2>
      <br>
      <br>
     

    </div>


	<form id="login" method="POST" action="">

                <div class="form-row ">
                        <div >
                                <label  class=""  for="validationCustom01">NAME : </label>
                                <input type="text" class="form-control"  name="name" id="validationCustom01" >
                        </div>




                        <div >
                                <label  for="validationCustomUsername">Username</label>
                                <div class="input-group">
                                        <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend">@</span>
                                        </div>
                                        <input type="text" class="form-control"  name="username" id="validationCustomUsername">
                                </div>
                        </div>


                </div>

                <div class="form-row ">                

                        <div >
                                <label class=""  for="validationCustom02">Email : </label>
                                <input type="text" class="form-control checking_email"  name="email"  id="validationCustom02" >
                                <small class="error_email" style="color: red;"> </small>
                        </div>

                </div>        

                <div class="form-row ">    
                        <div >
                                <label class="" for="validationCustom07">PHONE : </label>
                                <input type="number" class="form-control" name="phone" id="validationCustom07" >
                        </div>

                </div>  


                <button type="button" class="update" value="update" name="update" >Update</button>


            </form>



	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
 -->